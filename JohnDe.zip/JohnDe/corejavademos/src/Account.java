

/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class Account  {
	
	int actid;
	String name;
	double balance;
	static int ctr;
	 
	@Override
	public String toString()
	{
		return("Account details:"+actid+","+name+","+balance);
	}
	
	public boolean equals(Account a2)
	{
		if ((this.actid==a2.actid)&&((this.name).equals(a2.name))&&(this.balance==a2.balance))
			return true;
		else
			return false;
	}
	@Override
	public void finalize()
	{
		System.out.println("finalize invoked..");
	}
	
	
	
	public int hashCode()
	{
		return(actid+name.hashCode()+(int)balance);
		
		//return 13;
	}
	
	public Account(int actid,String n,double b)
	{
		//int ctr;
		this.actid=actid;
		name=n;
		balance=b;
		ctr++;
		System.out.println("param constr");
	}
	
	public Account()
	{
		//this();
		ctr++;		
		actid=ctr;
		name="aaa";
		ctr++;		
		System.out.println("paramless constr");
	}
	public Account(int a)
	{	actid=a;
		//this(23,a,45000);
		//name=a;
	}
	 public static void displayCtr()
	 {
		 System.out.println("ctr"+ctr);
	 }
	
	public void withdraw(double amt) //throws InsufficientBalanceException
	{
		
		try  {
		    if(balance>amt){
		    balance=balance-amt;
		    System.out.println("after withdrawal balance is:"+ balance);
		       } 
		    else
			throw new InsufficientBalanceException();
			} 
		   catch (InsufficientBalanceException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println(e);
				e.display();
			}
		}
	public void deposit(double amt)
	{
		balance=balance+amt;
		System.out.println("after deposite balance is:"+ balance);
		
	}
	public void displayAccountDetails()
	{
		System.out.println("Account details:Actid:"+this.actid+",Name:"+name+",Balance:"+balance+ctr);
	}
	
	public int getActid() {
		return actid;
	}
	public void setActid(int id) {
		actid = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	//@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Account details:Actid:"+this.actid+",Name:"+name+",Balance:"+balance);
	}

}
