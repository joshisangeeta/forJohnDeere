import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class NeedOfHandling {

	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		    
		       
		//FileOutputStream fos=new FileOutputStream("f1");
		
		
		
		
				/*try {
					FileOutputStream fos=new FileOutputStream("f1");
				   } 
				
				catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
				}
		*/
		
	//	System.out.println("div"+(10/0));
		int x = Integer.parseInt(args[0]);
		int y = Integer.parseInt(args[1]);
		
		
		
		try{
		
		
		System.out.println("Addition:"+(x+y));
		System.out.println("Division:"+(x/y));
		System.out.println("Multipl:"+(x*y));
		}
			
		catch(ArithmeticException e)
		{
			e.printStackTrace();
			
			System.out.println("can not divide by zero");
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
			
			System.out.println("array index outof bounds..");
		}
		
		//throw new Exception();
		System.out.println("Multipl:"+(x*y));
		
		System.out.println("hello..");

	}

}
