/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class InsufficientBalanceException extends Exception {

	/**
	 * 
	 */
	public InsufficientBalanceException() {
		// TODO Auto-generated constructor stub
	}
		
	public String toString()
		 {
			 return "You can not withdraw due to insufficient balance";
		 }
		

	
	
	  public void display()
	  {
		  System.out.println("balance insufficient");
	  }
}
