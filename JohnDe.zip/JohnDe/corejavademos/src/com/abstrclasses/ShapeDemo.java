/**
 * 
 */
package com.abstrclasses;

/**
 * @author sangeeta
 *
 */
public class ShapeDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	    // Shape s = new Shape();
	
	  Shape shapes[]= new Shape[3];	
	    shapes[0]= new Rectangle();
	    shapes[1]= new Circle();
	    shapes[2]= new Rectangle();
	    
	 for(int i=0;i<shapes.length;i++)   {
		 
		shapes[i] .calculateArea();
	 }
	    
	      Shape.isShape();
	    
	
	
	}

}
