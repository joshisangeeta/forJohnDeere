/**
 * 
 */
package com.abstrclasses;

/**
 * @author sangeeta
 *
 */
public abstract class Shape {
	
	
	  public  abstract void calculateArea();
	
	    public static void isShape(){
	    	System.out.println("this is a shape");
	    }
	

}

class Rectangle extends Shape{

	//@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		
	  System.out.println("Area of a rectangle is: b*h ");
	
	}
	
}

class Circle extends Shape{

	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		System.out.println("Area of a Circle is: pi*r*r");
	}
	
}










