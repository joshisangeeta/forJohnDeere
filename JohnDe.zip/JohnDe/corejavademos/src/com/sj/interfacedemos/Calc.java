/**
 * 
 */
package com.sj.interfacedemos;

/**
 * @author sangeeta
 *
 */
public interface Calc {

   
	public void add(int x,int y);


}
