/**
 * 
 */
package com.sj.interfacedemos;

/**
 * @author sangeeta
 *
 */
public class CalcA implements Calc{

	@Override
	public void add(int x, int y) {
		// TODO Auto-generated method stub
		System.out.println("CalcA adding.Sum is"+(x+y));
	
	}
	
	

}
