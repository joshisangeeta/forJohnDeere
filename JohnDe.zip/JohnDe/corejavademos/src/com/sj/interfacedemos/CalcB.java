/**
 * 
 */
package com.sj.interfacedemos;

/**
 * @author sangeeta
 *
 */
public class CalcB implements Calc {

	@Override
	public void add(int x, int y) {
		// TODO Auto-generated method stub
		System.out.println("Addition by B. Sum is:"+(x+y));
	}

}
