/**
 * 
 */
package com.sj.interfacedemos;

/**
 * @author sangeeta
 *
 */
public class User {

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public static void main(String[] args)   {
		// TODO Auto-generated method stub
				 
		Calc c;
		if(args[0].equals("calcA")){
		 c = new CalcA();
         }
         else 
        c= new CalcB();        
         
	    c.add(10, 3);	
		
		
		
		
		
		/* String calcProvider;
		if(args[0].equals("calcA")){
		 calcProvider="com.sj.interfacedemos.CalcA";
         }
         else 
        calcProvider="com.sj.interfacedemos.CalcB";
         
         
	    Calc c = (Calc) Class.forName(calcProvider).newInstance();
	
	        c.add(10, 3);*/
	
	
	}

}
