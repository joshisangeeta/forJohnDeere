/**
 * 
 */
package com.sj;

/**
 * @author sangeeta
 *
 */
public class Project implements Printable,Cloneable{
	
	int pid;
	String title;
	public Project(int pid, String title) {
		super();
		this.pid = pid;
		this.title = title;
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Project details:"+pid+title);
	}
	/*@Override
	public Project clone()
	{
		return new Project(1,"pr1");
	}*/
	@Override
	public String toString() {
		return "Project [pid=" + pid + ", title=" + title + "]";
	}
	
	
	
	
	
	
	

}
