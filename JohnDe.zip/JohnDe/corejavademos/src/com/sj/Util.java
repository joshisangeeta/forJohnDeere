/**
 * 
 */
package com.sj;

/**
 * @author sangeeta
 *
 */
public class Util {
	
	
	public static void printAll(Printable []p)
	{
		for(Printable p1:p)
		{
			p1.print();
		}
	}

}
