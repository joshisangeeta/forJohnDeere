/**
 * 
 */
package com.sj.abstrclassese;

/**
 * @author sangeeta
 *
 */
public abstract class Shape {
	
	public abstract void calculateShape();
	
	public void showType(){
		System.out.println("It is a Shape");
	}
	
}

class Rectangle extends Shape{

	@Override
	public void calculateShape() {
		// TODO Auto-generated method stub
		
	      System.out.println("Area of Rectangle is b*h");
	
	}	
}

class Triangle extends Shape{
	
	@Override
	public void calculateShape() {
		// TODO Auto-generated method stub
		
	      System.out.println("Area of Triangle is 0.5* b*h");

	}	

}
