/**
 * 
 */
package com.sj.io;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author sangeeta
 *
 */
public class IOdemo2 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
  
		FileOutputStream fos = new FileOutputStream("file2");
		DataOutputStream dos = new DataOutputStream(fos);
		
		FileInputStream fis = new FileInputStream("file2");
	    DataInputStream dis = new DataInputStream(fis);
	    
	     int x =10;
	     float y=10.5f;
	     double z= 24.78;
	     String s = "abc";
	     
	     dos.writeInt(x);
	     dos.writeFloat(y);
	     dos.writeDouble(z);
	     dos.writeUTF(s);
	
	     System.out.println((dis.readInt()));
	     System.out.println((dis.readFloat()));
	     System.out.println((dis.readDouble()));
	     System.out.println((dis.readUTF()));
	     
	     fos.close();
	     dos.close();
	     
	     
	
	
	
	
	
	
	}

}
