package com.sj.io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class IODemos {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		FileOutputStream fos = new FileOutputStream("file1");
		FileInputStream fis = new FileInputStream("file1");
		
		char i='a';
		while(i!='z'){
			
			i=(char) System.in.read();
			fos.write(i);
		}
		
		int x =1;
		while(x!= -1){
		     System.out.print( (char)fis.read());;
		}
		
	     fos.close();
	
	
	}
}
