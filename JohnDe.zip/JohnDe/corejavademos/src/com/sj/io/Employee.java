/**
 * 
 */
package com.sj.io;

import java.io.Serializable;

/**
 * @author sangeeta
 *
 */
public class Employee implements Serializable {

   private int eid;
    
    String name;

    double salary;
    
    public Employee(){
    	System.out.println("in emp paramless constr");
    }

	public Employee(int eid, String name, double salary) {
		super();
		this.eid = eid;
		this.name = name;
		this.salary = salary;
		System.out.println("in emp param constr");
	}
	
	public boolean equals(Employee e){
		if(this.eid == e.eid && this.name.equals(e.name)&& this.salary == e.salary)
			return true;
		else
			return false;
	}
	
	
     public void displayEmployee(){
    	 System.out.println("Employee details:"+eid+","+name+","+salary);
     }
	
	  public void calculateSalary(){
		  System.out.println("Total salary for employee:"+salary);
	  }
	  
	  public String toString(){
		  
		  return("Emp details:"+eid+","+name+","+salary);
	  }
	  
	  
	  
	  
	  
	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}
