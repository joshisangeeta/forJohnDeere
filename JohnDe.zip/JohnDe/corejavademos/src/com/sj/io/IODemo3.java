/**
 * 
 */
package com.sj.io;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author sangeeta
 *
 */
public class IODemo3 {

	/**
	 * @param args
	 * @throws   
	 */
	public static void main(String[] args) throws Exception  {
		// TODO Auto-generated method stub
	 FileOutputStream fos  = new FileOutputStream("myfile");
	 DataOutputStream dos = new DataOutputStream(fos);
	 int x =5;
	 float y = 1.2f;
	 double z=3.45;
	 String s = "abc";	
	 dos.writeInt(x);
	 dos.writeFloat(y);
	 dos.writeDouble(z);
	 dos.writeUTF(s);	 
	 FileInputStream fis = new FileInputStream("myfile");
	 DataInputStream dis = new DataInputStream(fis);
	 int x1 = dis.readInt();
	 float y1 = dis.readFloat();
	 double z1 = dis.readDouble();
	 String s1 = dis.readUTF();
	 
	 System.out.println(x1);
	 System.out.println(y1);
	 System.out.println(z1);
	 System.out.println(s1); 
	 
	 dos.close();
	 fos.close();
	}

}
