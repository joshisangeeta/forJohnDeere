/**
 * 
 */
package com.sj.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author sangeeta
 *
 */
public class IODemo4 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
	FileOutputStream fos = new FileOutputStream("EmpData");
	ObjectOutputStream oos = new ObjectOutputStream(fos);
	
	Employee e1 = new Employee(1,"abc",56000);
	oos.writeObject(e1);	
	FileInputStream fis = new FileInputStream("EmpData");
	ObjectInputStream ois = new ObjectInputStream(fis);
	Employee e2 = (Employee) ois.readObject();
	e2.displayEmployee();
	fis.close();
	ois.close();
	
	
	
	
	
	}

}
