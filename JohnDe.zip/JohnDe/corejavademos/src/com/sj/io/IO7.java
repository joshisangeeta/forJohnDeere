/**
 * 
 */
package com.sj.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author sangeeta
 *
 */
public class IO7 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub

	   FileOutputStream fos = new FileOutputStream("emps");		
	   ObjectOutputStream oos = new ObjectOutputStream(fos) ; 
	   Employee e = new Employee(1,"abc",80000);
	   oos.writeObject(e);	
	   FileInputStream fis = new FileInputStream("emps");
	   ObjectInputStream ois = new ObjectInputStream(fis);
	   Employee e1 = (Employee) ois.readObject();
	   System.out.println("Emp:"+e1);
	
	}

}
