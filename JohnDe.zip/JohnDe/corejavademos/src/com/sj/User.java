/**
 * 
 */
package com.sj;

/**
 * @author sangeeta
 *
 */
public class User {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Printable printable[] = new Printable[3];
         
              printable[0]= new Date(1,1,2001);
              printable[1]= new Employee(1,"abc",50000);
              printable[2]= new Employee(1,"xyz",60000);
	
          for(int i=0;i<printable.length;i++)   {
        	  
        	  
        	    printable[i].print();
        	  
          }
              
              
              
              
              
              
              /*printable[0]= new Resource(1,"resourceDescription");
	          printable[1]= new Project(1,"projectTitle");
	          printable[2]= new Resource(2,"resourceDescr2");*/
	         // Project p1 = (Project) printable[1];
	      Util.printAll(printable);          
	      // Project clonedOne = p1.clone();  
	       
	     //  System.out.println(clonedOne);
	    
	}
	 

}
