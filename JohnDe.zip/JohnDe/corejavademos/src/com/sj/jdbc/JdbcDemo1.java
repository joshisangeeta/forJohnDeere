/**
 * 
 */
package com.sj.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



/**
 * @author sangeeta
 *
 */
public class JdbcDemo1 {

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

	    Class.forName("com.mysql.jdbc.Driver");
	
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc1", "root", "root");
	
	    System.out.println("connection established");
	
	    Statement st = con.createStatement(); 
	    
	   ResultSet rs =  st.executeQuery("select * from emps");
	    
	  //    int i =  st.executeUpdate("insert into emps value(6,'qqq')");
	      
	 //   int i = st.executeUpdate("update emps set ename='mmm' where ename = 'qqq'" );
	             
	    
	    while(rs.next())
	    {
	    	System.out.println(rs.getString(1)+"-"+rs.getString(2));
	    }
	    
	    
	  // System.out.println(i);    
	  
	    rs.close();
	    con.close();
	    
	    
	    
	    
	    
	
	}

}
