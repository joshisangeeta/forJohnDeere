/**
 * 
 */
package com.sj.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author sangeeta
 *
 */
public class JdbcDemo2 {

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

	    Class.forName("com.mysql.jdbc.Driver");
	
	   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc1", "root", "root");
	
	   PreparedStatement pst =  con.prepareStatement("insert into emps values ( ?,?)");
	   pst.setInt(1,13);
	   pst.setString(2, "hdk");
	   int i = pst.executeUpdate();
	   
	   System.out.println(i);
	   //System.out.println(   pst.executeUpdate());
	   
	   
	   
	   con.close();
	   
	    /* PreparedStatement p
	     * 
	     * st =  con.prepareStatement("select * from emps where eid=?");
	   
       pst.setInt(1, 2);
       
       ResultSet rs = pst.executeQuery();
       
        while(rs.next()) {
        	System.out.println(rs.getInt(1)+rs.getString(2));
        }
       */
       
	   
	
	
	}

}
