/**
 * 
 */
package com.sj.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author sangeeta
 *
 */
public class JDBCDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	       try {
			Class.forName("com.mysql.jdbc.Driver");
		    Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/sj","root","root");
		    
		   /* For MariaDB : 
		    	Class.forName("org.mariadb.jdbc.Driver");  

	               Connection connection = DriverManager.getConnection(  
	                "jdbc:mariadb://localhost:3306/project", "root", "");*/  
		    		    
		    
	        Statement statement = connection.createStatement();
	       
	        ResultSet users = statement.executeQuery("select * from login");
	         while(users.next()){
	        	 
	        	 
	        	 System.out.println(users.getString(1)+","+users.getString(2));
	        	 
	             
	         }
	       
	         connection.close();   	
	       
	       } catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        
	      
	
	
	
	
	}

}
