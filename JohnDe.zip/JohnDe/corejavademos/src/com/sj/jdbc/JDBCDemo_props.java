/**
 * 
 */
package com.sj.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * @author sangeeta
 *
 */
public class JDBCDemo_props {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
        
		String driver,url,uid,password;
		
		Properties props = new Properties();
		InputStream input = new FileInputStream("F:/DBS/1DBS2/CoreJavaDemos/src/db.properties");
		props.load(input);
		driver = props.getProperty("driver");
		url = props.getProperty("url");
		uid = props.getProperty("uid");
		password = props.getProperty("passwordr");
		
	       try {
			Class.forName(driver);
		    Connection connection= DriverManager.getConnection(url,uid,password);
		    
		   /* For MariaDB : 
		    	Class.forName("org.mariadb.jdbc.Driver");  

	               Connection connection = DriverManager.getConnection(  
	                "jdbc:mariadb://localhost:3306/project", "root", "");*/  
		    		    
		    
	        Statement statement = connection.createStatement();
	       
	        ResultSet users = statement.executeQuery("select * from login");
	         while(users.next()){
	        	 
	        	 
	        	 System.out.println(users.getString(1)+","+users.getString(2));
	        	 
	             
	         }
	       
	         connection.close();   	
	       
	       } catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        
	      
	
	
	
	
	}

}
