/**
 * 
 */
package com.sj.collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author sangeeta
 *
 */
public class MapDemo1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	   HashMap<String,Integer> books = new HashMap<String,Integer>();
	
	     books.put("Ad Java", 450);
	     books.put("Spring in action", 670);
	     books.put("Let us c", 345);
	     Set<String> keys=   books.keySet();
	     Collection<Integer> values = books.values();
	     Iterator<String> keyItr = keys.iterator();
	     Iterator<Integer> valItr = values.iterator();
	     while(keyItr.hasNext()&& valItr.hasNext()){
	    	System.out.println(keyItr.next()+"-"+valItr.next());
	  	  }
	    // Entry e = new Entry("abc",450);
	     Set<Entry<String, Integer>> bookEntries = books.entrySet();
	     
	        Iterator<Entry<String, Integer>> bookItr=   bookEntries.iterator();
	     
	     while(bookItr.hasNext()){
	    	 System.out.println(bookItr.next());
	     }
	     
	     System.out.println(books);
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	}

}
