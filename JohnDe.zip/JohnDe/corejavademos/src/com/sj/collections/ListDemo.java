/**
 * 
 */
package com.sj.collections;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author sangeeta
 *
 */
public class ListDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	   ArrayList<Integer> numbers = new ArrayList<Integer>();
		
		//numbers.add(3.4);	
		
	  ArrayList<String> cities = new ArrayList<String>();
		       cities.add("Delhi");
	       cities.add("Pune");
	       cities.add("Mumbai");
	   //    cities.add(5);
	       cities.add("Chennai");
	
	for(String s:cities){
	
	         
		System.out.println("Length:"+ ( s).length());
		
	   }	
	 Iterator cityItr = cities.iterator();
	   
	 while(cityItr.hasNext()){
		  
		 String s= (String) cityItr.next();
		 System.out.println(s+ s.length());
		 
	 }
	
	
	}
	
	
	
}
