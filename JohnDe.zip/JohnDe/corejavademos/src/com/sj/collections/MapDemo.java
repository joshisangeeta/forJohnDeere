/**
 * 
 */
package com.sj.collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author sangeeta
 *
 */
public class MapDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	   HashMap<String,Integer> books = new HashMap<String,Integer>();
	
	   books.put("Java EE Black book",500);	
	   books.put("Lets C", 350);
	   books.put("Spring in action", 700);
	   books.put("Lets C", 400);
	   
	   System.out.println(books.get("Lets C"));
	   
	         Set<String> keys =books.keySet();
	         Collection<Integer> values = books.values();
	   
	   Iterator<String> keyItr = keys.iterator();
	   Iterator <Integer> valItr = values.iterator();

	   while(keyItr.hasNext()&& valItr.hasNext()){
		   
		   System.out.println(keyItr.next() +"-"+ valItr.next());
	   }
	 
	   
	   Set<Entry<String, Integer>> bookEntries = books.entrySet();
	   
	   Iterator<Entry<String, Integer>> entryItr = bookEntries.iterator();
	
	    while(entryItr.hasNext()){
	    	System.out.println(entryItr.next());
	    }
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
