/**
 * 
 */
package com.sj.collections;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author sangeeta
 *
 */
public class Collectiondemo_list {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Number> numbers = new ArrayList<Number>();
			
	    ArrayList<String> cities = new ArrayList<String>();
	    cities.add("Delhi");
	    cities.add("Mumbai");
	    cities.add("Pune");
	    //cities.add(4);
	    cities.add("Calcutta");	
	   for(String city:cities){
		   
		       System.out.println("Length of city:"+city+":"+ (city).length());
	   }	
	    Iterator <String>cityItr = cities.iterator();
	    Iterator <String> cityItr1 = cities.iterator();
	    while(cityItr.hasNext()){
	    	   
	    	String s =  cityItr.next();
	    	/*if(s.equals("Pune"))
	    		cityItr.remove();
	    	else*/
	    	System.out.println(s.length());
	    }	  
	    while(cityItr1.hasNext()){  	   
	    	
	    	System.out.println(cityItr1.next());
	    }
	    
	    System.out.println(cities);
		
	}

}
