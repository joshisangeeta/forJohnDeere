/**
 * 
 */
package com.sj.collections;

import java.util.SortedSet;
import java.util.TreeSet;

/**
 * @author sangeeta
 *
 */
public class SortedDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	 SortedSet <Book> books = new TreeSet<Book>();
	
	 books.add(new Book(21,"abc",550));
	
	 books.add(new Book(11,"xyz",340));
	
	 books.add(new Book(13,"zys",750));
	
	  for(Book b:books){
		  System.out.println(b);
	  }
	 
	 
	 
	 
	 
	     
	
	}

}
