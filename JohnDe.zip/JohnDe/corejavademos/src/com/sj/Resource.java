/**
 * 
 */
package com.sj;

/**
 * @author sangeeta
 *
 */
public class Resource  implements Printable{
     int resource_id;
     String technology;
	public Resource(int resource_id, String technology) {
		super();
		this.resource_id = resource_id;
		this.technology = technology;
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Resource:"+resource_id+technology);
	}
}
