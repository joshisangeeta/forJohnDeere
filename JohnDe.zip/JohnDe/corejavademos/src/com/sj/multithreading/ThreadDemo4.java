/**
 * 
 */
package com.sj.multithreading;

/**
 * @author sangeeta
 *
 */
public class ThreadDemo4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Thread tm =new Thread4();
		
		 Thread t1 = new Thread(tm,"t1");
		 Thread t2 = new Thread(tm,"t2");
		 t1.setName("t1");	  
	     t2.setName("t2");
	    t1.start();
	    t2.start();
	    System.out.println("main thread running");
	}

}

class Thread4 extends Thread {
	
	int x;
	
	public void run(){
		
        if(Thread.currentThread().getName().equals("t1")){
       	 System.out.println("t1 is incrementing x"+(++x));
        }
        else
       	 System.out.println("t2 is decrementing x"+(--x)); 
	}
	
	
	
}
