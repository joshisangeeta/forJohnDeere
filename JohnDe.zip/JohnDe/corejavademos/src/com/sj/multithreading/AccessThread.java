/**
 * 
 */

package com.sj.multithreading;
/**
 * @author sangeeta
 *
 */
public class AccessThread extends Thread {

	  MyAccount a1;
	
	  
	
	public AccessThread(MyAccount a1) {
		super();
		this.a1 = a1;
	}
    @Override
    public void run()
    {
    	if(Thread.currentThread().getName().equals("t1"))
    	{
    		a1.withdraw(3000);
    	}
    	if(Thread.currentThread().getName().equals("t2"))
    	{
    		a1.deposite(4000);
    	}
    	
    	  try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
	    MyAccount a1 = new MyAccount();
		
		AccessThread at1=new AccessThread(a1);
	
	       Thread t1 =  new Thread(at1,"t1");
	       Thread t2 =  new Thread(at1,"t2");
	       t1.start();
	       t2.start();
	
	}

}
