/**
 * 
 */
package com.sj.multithreading;

/**
 * @author sangeeta
 *
 */
public class MyThreadDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		Thread t1 = new MyThread();
		  t1.setName("t1");
		Thread t2 = new MyThread();
		  t2.setName("t2");
	          t1.start();
	          t2.start();
	
	   System.out.println("main thread");
	
	}

}
class MyThread extends Thread{
	int x;
	int y;
	@Override
	public void run(){
		if (Thread.currentThread().getName().equals("t1"))
		System.out.println("t1 getting executed: x:"+(++x));
		else
		System.out.println("t2 getting executed: y:"+(++y));	
		   try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}










