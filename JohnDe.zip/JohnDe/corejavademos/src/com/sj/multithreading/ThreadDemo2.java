/**
 * 
 */
package com.sj.multithreading;

/**
 * @author sangeeta
 *
 */
public class ThreadDemo2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {		// TODO Auto-generated method stub

	  MyThread1 mt = new MyThread1();
		
	Thread t1 = new Thread(mt,"t1");
	Thread t2 = new Thread(mt,"t2");
	 // t1.setName("t1");
	 // t2.setName("t2");
      t1.start();
      t2.start();

 System.out.println("main thread");

   }

}

class MyThread1 extends Thread{
	
int x;
	
     public void run(){
    	 
    	if (Thread.currentThread().getName().equals("t1")) 
    	{
    		System.out.println("t1 incrementing x"+(++x));
    	}
    	else
    		
    		System.out.println("t2 decrementing x"+(--x));
     }
	
	




}
