import java.awt.*;
import java.awt.event.*;
import java.util.Random;
class Game1 extends Frame implements Runnable,MouseListener,ActionListener
{
	Thread t1,t2,t3,t4;
	int x1=5,x2=240,x3=425,x4=240,y1=250,y2=25,y3=250,y4=425;
	int mx,my;
	int flag=0;
	int score=0;
	Color c1,c2,c3,c4;
	Random r;
	public Game1()
	{
		t1=new Thread(this,"t1");
        t2=new Thread(this,"t2");
        t3=new Thread(this,"t3");
        t4=new Thread(this,"t4");
		r=new Random();

		t1.start();
		t2.start();
		t3.start();
		t4.start();
		c1=Color.blue;
		c2=Color.green;
		c3=Color.red;
		c4=Color.yellow;
	     addMouseListener(this);
				     
	}
	public void run()
	{
		try
		{
			for(;;)
			{
				 if(Thread.currentThread()==t1)
				{                       
				     x1=r.nextInt(450);
					 y1=r.nextInt(450);
                    Thread.sleep(500);
					 repaint();
				}
				if(Thread.currentThread()==t2)
				{                       
				     x2=r.nextInt(450);
					 y2=r.nextInt(450);
                    Thread.sleep(1000);
					 repaint();
				}
				if(Thread.currentThread()==t3)
				{                       
				     x3=r.nextInt(450);
					 y3=r.nextInt(450);
                    Thread.sleep(1500);
					 repaint();
				}
               if(Thread.currentThread()==t4)
				{                       
				     x4=r.nextInt(450);
					 y4=r.nextInt(450);
                    Thread.sleep(2000);
					repaint();
				}
            }
		}
		catch (Exception e)
		{
		}
	}
	public void paint(Graphics g)
		{
		           		  g.setColor(c1);
					      g.drawOval(x1,y1,50,50);
						   g.fillOval(x1,y1,50,50);
		             		 g.setColor(c2);
								g.drawOval(x2,y2,50,50);
								g.fillOval(x2,y2,50,50);
					         	g.setColor(c3);
								g.drawOval(x3,y3,50,50);
								g.fillOval(x3,y3,50,50);
				                g.setColor(c4);
								g.drawOval(x4,y4,50,50);
								g.fillOval(x4,y4,50,50);
								if (((((x2-x1)<=60)&&(x2-x1)>=0)||((x1-x2)>=-25)&&(x1<=x2)) &&(((y1-y2)<25)||((y2-y1)>-60)))
			                    //if ((((x2-x1)<100)||((x1-x2)>-50)) &&(((y1-y2)<50)||((y2-y1)>-100)))
								  {
                                        g.setColor(Color.magenta);
										 g.drawString("HI",100,100);
									 }
								if(flag==1)
			                       {
									  g.setColor(Color.magenta);
									  g.drawString("HI",mx,my);
                                       g.drawArc(mx-50,my-30,100,60,0,-180);
									   g.fillArc(mx-50,my-30,100,60,0,-180);
								   }
			}
			public void mouseClicked(MouseEvent e)
			{
			   flag=1;
			   mx=e.getX();
			   my=e.getY();
			  // repaint();
			}
			public void mousePressed(MouseEvent e)
			{
			   
			}
			public void mouseReleased(MouseEvent e)
			{
			}
			public void mouseEntered(MouseEvent e)
			{
			 }
			 public void mouseExited(MouseEvent e)
			{
			 }
				 public void actionPerformed(ActionEvent ae)
				{

				}
				
                
	public static void main(String[] args) 
	{
		Game1 gm=new Game1();
		gm.setSize(500,500);
		gm.setVisible(true);
		System.out.println("Hello World!");
	}
}
