/**
 * 
 */
package com.sj.multithreading;

/**
 * @author sangeeta
 *
 */
public class MyAccount {
	
	int balance;
	synchronized public void withdraw(int amt)
	{
		balance=balance-amt;
		System.out.println("balance after withdraw:"+balance);
	}
	
	synchronized public void deposite(int amt)
	{
		balance=balance+amt;
		System.out.println("balance after deposite:"+balance);
	}

	public MyAccount() {
		super();
		// TODO Auto-generated constructor stub
		balance =5000;
	}
	
	
}
