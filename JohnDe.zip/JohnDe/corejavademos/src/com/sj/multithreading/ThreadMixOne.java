/**
 * 
 */
package com.sj.multithreading;

/**
 * @author sangeeta
 *
 */
public class ThreadMixOne {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub	
	
	   Thread6 t6 = new Thread6();
	
	   System.out.println("in main");
	
	
	}

}
class Thread6 extends Thread{
  Thread t1,t2;
  int x1,x2;
  
     public Thread6(){
    	 x1 = 0;
    	 x2 = 400;    	 
    	t1= new Thread(this,"t1") ;
    	t2 = new Thread(this,"t2") ;    	 
    	t1.start();
    	t2.start();
     }	
	public void run(){
		   for(int i=0;i<100;i++){
	       	 if(Thread.currentThread()==t1){
	    		 if(x1<400){
	    			 x1=x1+5;
	    			 System.out.println("x1:"+x1);
	    		 }
	    		 else
	    		  {
	    			  x1=0;
	    		  }
	    	  } 
	       	if(Thread.currentThread()==t2){
	    		 if(x2>0){
	    			 x2=x2-5;
	    			 System.out.println("x2:"+x2);
	    		 }
	    		 else
	    		  {
	    			  x2=400;
	    		  }
	    		 
	    	  } 
	    	try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	     
	
	
	     }
	
	
	}
	
	
	
}
