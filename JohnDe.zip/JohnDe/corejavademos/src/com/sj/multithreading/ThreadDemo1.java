/**
 * 
 */
package com.sj.multithreading;

/**
 * @author sangeeta
 *
 */
public class ThreadDemo1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
		 Thread t1 = new Thread1();
		 t1.start();
		 System.out.println("main thread executing");
	
	}

}

class Thread1 extends Thread{
	int i;
	
	      public void run(){
	    	  System.out.println("Mythread1 runnig:incrementing i:"+(++i));
	      }
	
	
}
