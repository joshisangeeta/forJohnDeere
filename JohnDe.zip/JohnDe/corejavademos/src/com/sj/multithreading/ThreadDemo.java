class ThreadDemo extends Thread
{
	Thread t1,t2,t3;
	ThreadDemo()
	{
		
		t1=new Thread(this,"t1");
		t2=new Thread(this,"t2");
		t3=new Thread(this,"t3");
		t1.start();
		t2.start();
		t3.start();
		//t1.stop();
		
	}
	public void run()//throws InterruptedException
	{
		try{
			
		if(Thread.currentThread().equals(t1))
		System.out.println("The thread t1 is running");
		else if ((Thread.currentThread().equals(t2)))
		
			System.out.println("The thread t2 is running");
		else if ((Thread.currentThread().equals(t3)))
		
			System.out.println("The thread t3 is running");
		  else
        System.out.println("The thread main is running");
		
			Thread.sleep(200);
			System.out.println(Thread.currentThread().getName());
		
		}
		catch(InterruptedException e)
		{
		}
		
	}
	/*public void stop()
	{
      System.out.println("The thread is stopped");
	
    }*/
	public static void main(String[] args)throws Exception 
	{
		ThreadDemo td=new ThreadDemo();
		
		
		System.out.println("Hello World!");
	}
}
