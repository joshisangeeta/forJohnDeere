/**
 * 
 */
package com.sj.interfaces;

/**
 * @author sangeeta
 *
 */
public class User {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calc c1;
	   if(args[0].equals("CalcA"))
	   {
		    c1 = new CalcA();
	   }
	   else
		  c1 = new CalcB();	
		   
	   c1.add(13, 0);
	
	
	}

}
