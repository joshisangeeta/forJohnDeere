/**
 * 
 */
package com.sj.interfaces;

/**
 * @author sangeeta
 *
 */
public class CalcA implements Calc{


       public void add(int x,int y){
    	   System.out.println("service by A.Sum:"+(x+y));
       }



}
