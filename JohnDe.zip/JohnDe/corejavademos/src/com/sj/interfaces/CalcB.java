/**
 * 
 */
package com.sj.interfaces;

/**
 * @author sangeeta
 *
 */
public class CalcB implements Calc {

	 public void add(int x,int y){
  	   System.out.println("service by B.Sum:"+(x+y));
     }


	
	
}
