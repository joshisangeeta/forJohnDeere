package com.sj.interfaces;

public interface Calc {

     public void add(int x,int y);

}
