/**
 * 
 */
package com.sj.exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author sangeeta
 *
 */
public class ExceptionDemo {

	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
        System.out.println("Exc demo");
       
       InputStream os = new FileInputStream ("abc1");
          
        /*try{
	       System.out.println("div:"+(10/0));
         }
        catch(ArithmeticException e)
        {
        	System.out.println("can not divide by 0");
        }*/
        
	    System.out.println("continued with further code");
	  
	
	
	
	
	}

}
