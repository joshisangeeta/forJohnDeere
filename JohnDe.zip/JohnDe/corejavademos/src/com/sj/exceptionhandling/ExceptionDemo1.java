/**
 * 
 */
package com.sj.exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * @author sangeeta
 *
 */
public class ExceptionDemo1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	    System.out.println("Exc demo");
	  //  FileInputStream fos = new FileInputStream("f2");  
	    
	    try {
			FileInputStream fos1 = new FileInputStream("f2");
		     
	      } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		  }
	    
	    System.out.println("contnd program execution");
	
	
	
	}

}
