/**
 * 
 */
package com.sj;

/**
 * @author sangeeta
 *
 */
public interface Printable {
	
	public void print();

}
