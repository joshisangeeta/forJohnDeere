
public class PropgDemo {
	
	
	   public static void main(String[] args)throws Exception 
	   {
		
		   
		   
		   PropgDemo p1 =new PropgDemo();
		 //p1.m1();
		   try {
				p1.m1();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("m3's exception handled in main");
			}
			finally{   
				System.out.println("clean up code");
			}
		   
		   
	}	
	public void m1()throws Exception
	{
		System.out.println("m1 called");
		m2();
	}

	public void m2() throws Exception
	{
		// TODO Auto-generated method stub
		System.out.println("m2 called");
		m3();
	}

	public void m3() throws Exception 
	{
		// TODO Auto-generated method stub
		System.out.println("m3 called");
		throw new Exception();
	}
	
	
}
