/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class NegativeNoException extends Exception {

	@Override
	public String toString() {
		return "Do not enter a number less than 0";
	}
	
	public void showMsg()
	{
		System.out.println("Do not enter a number less than 0");
	}

	
}
