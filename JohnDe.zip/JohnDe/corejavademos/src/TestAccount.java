import org.junit.After;
import org.junit.Before;
import org.junit.Test;

//@RunWith(value = BlockJUnit4ClassRunner.class)
public class TestAccount {
    Account account;
	@Before
	public void setUp() throws Exception {
	   account =new Account();
	   account.setBalance(5000);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected=InsufficientBalanceException.class)
	public final void testWithdraw() throws InsufficientBalanceException {
		
		account.withdraw(6000);
		// assertFalse(throwException());
		
		//fail("Not yet implemented"); // TODO
	}

}
