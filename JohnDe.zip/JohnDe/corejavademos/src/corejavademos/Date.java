/**
 * 
 */
package corejavademos;

/**
 * @author sangeeta
 *
 */



public class Date {

 
  private  int dd;
  private  int mm;
  private int yy;   
    
   static int ctr;
    
    public Date(){
    	ctr++;
    	
    	System.out.println("parameterless constr ...");
    }
  
   public Date(int dd,int mm,int yy){
	   ctr++;
	  this.dd=dd;
	  this.mm=mm;
	  this.yy=yy;
	  System.out.println("In param constr");
   }
 
  
   public static void showCounter(){
	   System.out.println("No of objects created:"+ctr);
   }
    
   
   public boolean equals(Date d1){
	   if(this.dd==d1.dd && this.mm==d1.mm && this.yy==d1.yy)
		   return true;
	       return false;
   }
   
   
      public int getDd() {
	return dd;
}



public void setDd(int dd) {
	this.dd = dd;
}



public int getMm() {
	return mm;
}



public void setMm(int mm) {
	this.mm = mm;
}



public int getYy() {
	return yy;
}

public String toString(){
	return ("The date is:"+dd+","+mm+","+yy);
}


public void setYy(int yy) {
	this.yy = yy;
}



	public void setDate(int d,int m,int y){
    	  
    	  dd=d;
    	  mm=m;
    	  yy=y;
      }
  
  

    public void displayDate(){
    
  
    System.out.println("The date is:"+dd+","+mm+","+yy+"ctr:"+ctr);
       
    
    }
    








}
