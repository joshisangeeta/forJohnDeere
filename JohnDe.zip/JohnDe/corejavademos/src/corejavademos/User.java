/**
 * 
 */
package corejavademos;

/**
 * @author sangeeta
 *
 */


public class User {
	

	public User(){
		System.out.println("user constr");
	}
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 System.out.println("in main..");		
	  Date d2 = new Date(1,1,2001);	  
	  Date d1 = new Date(2,2,2002);
	  Date.showCounter();
	  Date d3 = new Date();	
	  d3.displayDate();  	    
	  Date.showCounter();
	 
	}

}
