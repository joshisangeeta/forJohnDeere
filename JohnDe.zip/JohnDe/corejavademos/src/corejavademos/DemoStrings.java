/**
 * 
 */
package corejavademos;

/**
 * @author sangeeta
 *
 */
public class DemoStrings {


	public static void main(String[] args) {


		String s1 = new String("abc");
        String s2 = new String("abc");
        
        String s3 = "abc";
      //  String s4= "abc";
        System.out.println(s2.equals(s1));  
        
        System.out.println(s2==s1);
     //   System.out.println(s3==s4);
        
     //   System.out.println(s3.charAt(1));
      //  System.out.println(s3.length());       

       Date d1 = new Date(1,1,2001);
        Date d2 = new Date(1,1,2001);
        
        System.out.println(d1.equals(d2));
      
     

	}


}
