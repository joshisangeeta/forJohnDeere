/**
 * 
 */
package corejavademos;

/**
 * @author sangeeta
 *
 */
public class DemoUser {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
            
	  Employee e1 = new Employee(1,"abc",60000);
	  
	  Date d1 = new Date (1,2,3);
	  Employee m1 = new Manager(2,"xyz",60000,45000);
	  System.out.println(e1);
	  System.out.println(d1);
	  System.out.println(m1);
		
		/*Employee emps[]= new Employee[3];
		  emps[0]= new Employee(1,"abc",60000);
		  emps[1]= new Manager(2,"xyz",60000,45000);
		  emps[2]= new Employee(1,"emp2",70000);
		
		for(int i=0; i<emps.length;i++){
			
		     emps[i].calculateSalary();
		
		}
		
	   
		
		
		
		
		
		
		
		*/
		
		
		/*Date dates[]= new Date[2];
	
	      dates[0]= new Date();
	      dates[1]= new Date(1,1,2001);
	
	    for(int i=0;i<2;i++){
	    	
	    	dates[i].displayDate();
	    }*/
	 
	    
	    
	
	
	
	
	}

}
