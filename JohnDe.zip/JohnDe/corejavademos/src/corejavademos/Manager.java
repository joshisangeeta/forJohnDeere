/**
 * 
 */
package corejavademos;

/**
 * @author sangeeta
 *
 */
public class Manager extends Employee {

    double allownce;


      public Manager(){
    	  System.out.println("mgr paramless constr");
      }
    
      public Manager(int id,String n,double sal,double allo)
      { 
    	 // super()
    	 super(id,n,sal);
    	  allownce=allo;
    	  System.out.println("in mgr param constr");
      }
    
      public void calculateSalary(){
    
    	 
    	    System.out.println("Total salary of manager:"+(salary+allownce)); 
    	  
      }
      
      public void showAllow(){
    	  System.out.println("allownce is:"+allownce);
      }
      
       public String toString(){
    	 return(  super.toString()+this.allownce);
       }
      
      
      

}
