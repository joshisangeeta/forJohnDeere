package corejavademos;

public class UserEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	    Employee e1 = new Employee(1,"abc",70000);
	    
	    Employee m1 = new Manager(2,"xyz",80000,10000);
		           
	      m1.displayEmployee();
	  
	      m1.calculateSalary();  
	     ((Manager) m1).showAllow();
          e1.calculateSalary();
	
	
	
	
	}

}
