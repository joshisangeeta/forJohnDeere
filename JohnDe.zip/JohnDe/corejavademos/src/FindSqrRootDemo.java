
public class FindSqrRootDemo {

	public static void main(String[] args)// throws NegativeNoException {
	{// TODO Auto-generated method stub

	    int x = Integer.parseInt(args[0]);
	    try {
	     
	         if (x>=0)
		      {
			    System.out.println("Sqr root of X is"+Math.sqrt(x));
		       } else
			
				throw new NegativeNoException();
			   } catch (NegativeNoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			  }
	    //System.out.println("hi");
	
	}

}
