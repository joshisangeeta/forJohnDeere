/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class Demo {
	
		/**
		 * @param args
		 */
		public static void main(String[] args) {
			// TODO Auto-generated method stub
	          //1
		    //  Greeter greeter = new Greeter();
		     //         greeter.greet();
		
		       //2       
		              
		              Greeter greeter = new Greeter();
		         //     greeter.greet(new HiGreeting());
		              
		     //Appr-5 Lambda
		      /*        Greeter greeter1 = new Greeter();----using class definition of Appr 2 onwards     
		       greeter.greet(()->System.out.println("Hello world"));*/
		}


}
