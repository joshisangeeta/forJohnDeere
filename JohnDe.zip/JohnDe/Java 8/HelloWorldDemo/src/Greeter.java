/**
 * 
 */

/**
 * @author sangeeta
 *
 */
 
	/*public class Greeter{

	   public void greet(){
		   System.out.println("hello world");
	   }

	 }*/
		
	//for all remainng approaches:
	
	interface Greeting{
		public void perform();
	}
	
	//Approach 2
	/*interface Greeting{
		public void perform();
	}
	class HelloGreeting implements Greeting
	{
	        public void perform()
	        {
	           System.out.println("hello world");
	        }
	}
	class HiGreeting implements Greeting
	{
	        public void perform()
	        {
	           System.out.println("hi world");
	        }
	}
	public class Greeter{

	   public void greet(Greeting greeting){
		   greeting.perform();
	   }
	}*/
	
	//Approach 3
	// Create them as nested classes
	
	
	
	     public class Greeter{

	       public void greet(Greeting greeting){
		   greeting.perform();
	   
	        }
	   
	     static  class HiGreeting implements Greeting
	       {
	            public void perform()
	           {
	           System.out.println("hi world");
	           }
	      } 
	    static  class HelloGreeting implements Greeting
	      {
	        public void perform()
	        {
	           System.out.println("hello world");
	        }
	       }  
	   
	    }
	
	
	/*
	 * Approach 4 :  anonymous inner classes
	 * 
	 *   public class Greeter{

	       public void greet(Greeting greeting){
		   greeting.perform();
	   
	        }	   
	   
	       --------in main ----
	          new Greeter().greet(new Greeting(){
	                 public void perform()
	                 {
	                     
	                     System.out.println("hello world");
	                 }});
	   }
	 * 
	 * */	
	
	/*
	 * Approach 5 : Lambda
	 * 
	 *      ---      in main----
	 * 
	 *          new Greeter().greet(()->System.out.printn("hello world"));
	 *           new Greeter().greet(()->System.out.printn("hi world"));
	 *           
	 *               (int x)->{
	 *                    return(x*x);
	 *                    }
	 *              
	 * */
	
	
	
	
	
	 