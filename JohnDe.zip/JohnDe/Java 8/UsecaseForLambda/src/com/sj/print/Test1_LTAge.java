/**
 * 
 */
package com.sj.print;

import com.sj.model.Person;

/**
 * @author sangeeta
 *
 */
public class Test1_LTAge implements Tester{

	@Override
	public boolean test(Person p) {
		// TODO Auto-generated method stub
		return (p.getAge()<20);
	}

}
