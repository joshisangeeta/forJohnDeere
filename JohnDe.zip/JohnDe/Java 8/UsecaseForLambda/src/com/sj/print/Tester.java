/**
 * 
 */
package com.sj.print;

import com.sj.model.Person;

/**
 * @author sangeeta
 *
 */
public interface Tester {
	
	
	public boolean test(Person p);
	

}
