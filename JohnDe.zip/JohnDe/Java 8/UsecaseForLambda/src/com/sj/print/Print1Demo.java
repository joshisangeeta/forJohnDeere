package com.sj.print;

import java.util.ArrayList;
import java.util.List;

import com.sj.model.Person;

public class Print1Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	    List <Person> persons = new ArrayList<Person>();
	
	  
	        persons.add(new Person("aaa",1));
	        persons.add(new Person("bbb",51));
	        persons.add(new Person("ccc",21));
	        persons.add(new Person("ddd",31));
	        persons.add(new Person("eee",11));
	        
	       /*  ///Approach 1.
	        System.out.println("Approach1...lessThan20");
	        LessThanPrinter1.print(persons);
	        System.out.println("-------------");
	        ///Approach1..changing criteria
	        System.out.println("Approach1-2..changing criteria");
	        InRangePrinter2.print(persons);
	        System.out.println("-------------");
	        //Approach 3......local classes
	        System.out.println("Approach3..local classes");
	        Tester tester = new Printer.LTAge();
	        Printer.print(persons,tester);
	        Tester irtester = new Printer.InRange();      
	   	        
	        Printer.print(persons,irtester);
	        System.out.println("-------------");
	        
	        
	        //Approach 4.......anonymous inner classes
	        System.out.println("Approach4..anonymous inner classes");
	        Printer.print(persons, new Tester(){public boolean test(Person p){return(p.getAge()<20);}});
	        Printer.print(persons, new Tester(){public boolean test(Person p){return(p.getAge()<40 && p.getAge()>20) ;}});
	        System.out.println("-------------");
	        */
	        //Approach 5.......Lambda expressions
	        System.out.println("Approach5..lambda expressions");
	        
	        Printer.print(persons, (p)->(p.getAge()<20));
	        Printer.print(persons, (p)->( (p.getAge() < 40)&&(p.getAge()>20)));
	        
	
	
	}

}
