package com.sj.print;

import java.util.List;

import com.sj.model.Person;

public class LessThanPrinter1 {
	
	
	   public static void print(List<Person>p)
	   {
		   
		   for(Person p1:p)
		   {
			   if(p1.getAge()<20)
				   System.out.println("Persons filtered:"+p1);
				   
		   }
		   
	   }
	
	
	
	

}
