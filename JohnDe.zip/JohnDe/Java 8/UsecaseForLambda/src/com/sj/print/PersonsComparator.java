/**
 * 
 */
package com.sj.print;

import com.sj.model.Person;

/**
 * @author sangeeta
 *
 */
public class PersonsComparator {

        boolean   testPrinter(Person p,Tester t)
        {
        	return t.test(p);
        }

}
