/**
 * 
 */
package com.sj.print;

import java.util.List;

import com.sj.model.Person;

/**
 * @author sangeeta
 *
 */
public class Printer {
	
	   public static void print(List<Person>p,Tester t ) {
	
	         for(Person person:p)
	         {
	        	 if(t.test(person))
	        		 
	        	  System.out.println(person);
	         }
	   
	   } 
	   
	  
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   static class LTAge implements Tester{

			@Override
			public boolean test(Person p) {
				// TODO Auto-generated method stub
			//	System.out.println("testing with Less Than tester");
				return (p.getAge()<20);
			}

		}
	   
	   
	  static class InRange implements Tester{

		@Override
		public boolean test(Person p) {
			// TODO Auto-generated method stub
			//System.out.println("testing with inrange tester");
			return (p.getAge()<40 && p.getAge()>20 );
		}
		   
	   }
	   
	   
	   

}
