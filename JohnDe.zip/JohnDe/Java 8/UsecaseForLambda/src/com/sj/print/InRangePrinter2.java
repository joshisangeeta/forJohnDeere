package com.sj.print;

import java.util.List;

import com.sj.model.Person;

public class InRangePrinter2 {

	 public static void print(List<Person>p)
	   {
		   
		   for(Person p1:p)
		   {
			   if(p1.getAge()>20 && p1.getAge()<40)
				   System.out.println("Persons filtered:"+p1);
				   
		   }
		   
	   }

}
