/**
 * 
 */
package com.sj.model;

import java.time.LocalDate;

/**
 * @author sangeeta
 *
 */
public class Person {
	
	String name;
	int age;
	
	
	 public Person(String name,int age)
	 {
		 this.name=name;
		 this.age=age;
	 }
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

	public enum Sex
	{
		MALE,FEMALE;
	}
	
	LocalDate birthday;
    Sex gender;
    String emailAddress;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public LocalDate getBirthday() {
		return birthday;
	}
	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}
	public Sex getGender() {
		return gender;
	}
	public void setGender(Sex gender) {
		this.gender = gender;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	
	
	
	
	

}
