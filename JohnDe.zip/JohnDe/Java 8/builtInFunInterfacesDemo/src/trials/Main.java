package trials;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	 
	
	       List<Integer> numbers = new ArrayList<Integer> ();
	          numbers.add(1);
	          numbers.add(11);
	          numbers.add(10);
	          numbers.add(81);
	          numbers.add(12);
	          numbers.add(24);
	         
	          
	     numbers.forEach((v)->System.out.println(v));
	
	   numbers.forEach(System.out::println);
	
	
	}

}
