/**
 * 
 */
package com.sj;

/**
 * @author sangeeta
 *
 */
public interface MathOperation {
	
	int operate (int x,int y);

}
