/**
 * 
 */
package com.sj;

/**
 * @author sangeeta
 *
 */
@FunctionalInterface
public interface PersonComparator {

	int comparePersons(Person p1,Person p2);

}
