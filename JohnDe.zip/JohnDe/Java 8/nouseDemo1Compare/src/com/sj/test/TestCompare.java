/**
 * 
 */
package com.sj.test;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.sj.Person;

/**
 * @author sangeeta
 *
 */
public class TestCompare {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	
		List<Person> people = Arrays.asList(
			      new Person("Ted", "Neward", 42),
			      new Person("Charlotte", "Neward", 39),
			      new Person("Michael", "Neward", 19),
			      new Person("Matthew", "Neward", 13),
			      new Person("Neal", "Ford", 45),
			      new Person("Candy", "Ford", 39),
			      new Person("Jeff", "Brown", 43),
			      new Person("Betsy", "Brown", 39)
			    );
	
	    /* 
	     *    One way of comparing::
	     *    
	     * Collections.sort(people,new Comparator<Person>(){

			@Override
			public int compare(Person lhs, Person rhs) {
				if(lhs.getLname().equals(rhs.getLname()))
				// TODO Auto-generated method stub
				return (lhs.getAge()-rhs.getAge());
				
				else
					return(lhs.getLname().compareTo(rhs.getLname()));
			}
	      });*/
		
		
				
		/* 
		 *   third way :: using lambda
		 * 
		 * */
		
		Collections.sort(people,(lhs,rhs)->{if(lhs.getLname().equals(rhs.getLname()))
				// TODO Auto-generated method stub
				return (lhs.getAge()-rhs.getAge());
				
				else
					return(lhs.getLname().compareTo(rhs.getLname()));});
		
		/*
		 *  second way - using static inner comparator class
		 * 
		  Person.PersonCompare p1=new Person.PersonCompare();
	         Collections.sort(people,p1);*/
		
		
		Collections.sort(people,Person.PersonCompare);
		
	       System.out.println(people);
	
	
	
	
	
	
	
	}

}
