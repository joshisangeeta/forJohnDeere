/**
 * 
 */
package com.sj;

/**
 * @author sangeeta
 *
 */


public class Demo
{

	  public static void main(String []args)
	  {
Converter <String,Integer> cvt = from -> Integer.valueOf(from);


Integer i=cvt.convert("123");

System.out.println(i);

Converter <Integer,String > cvt1 = from1-> from1.toString();

    String s =cvt1.convert(1234);

    System.out.println(s);

    
    Converter currency = inr -> Integer.parseInt(inr)*68;
    
    

	  }

}

interface Converter <F,T>{
	
	 T  convert(F from);
	}