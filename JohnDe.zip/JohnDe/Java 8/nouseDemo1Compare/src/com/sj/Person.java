/**
 * 
 */
package com.sj;

import java.util.Comparator;

/**
 * @author sangeeta
 *
 */
public class Person {
  String fname,lname;
  int age;
  
    /*  
     *  econd way - using static inner comparator class
     * 
     * public static  class PersonCompare implements Comparator<Person>{

	@Override
	public int compare(Person lhs,Person rhs) {
		// TODO Auto-generated method stub
		
		if(lhs.getLname().equals(rhs.getLname()))
			// TODO Auto-generated method stub
			return (lhs.getAge()-rhs.getAge());
			
			else
				return(lhs.getLname().compareTo(rhs.getLname()));
		
		
	         }
	  
                 }*/ 
  
    public static Comparator <Person> PersonCompare = (lhs,rhs)->{
    	   if(lhs.getLname().equals(rhs.getLname()))
    		   return (lhs.getAge()-rhs.getAge());
    	return(lhs.getLname().compareTo(rhs.getLname()));};
  
  
  
  
   public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public Person(String fname, String lname, int age) {
	super();
	this.fname = fname;
	this.lname = lname;
	this.age = age;	
	
        }
@Override
public String toString() {
	return "Person [fname=" + fname + ", lname=" + lname + ", age=" + age + "]";
}
   
   
  
}
