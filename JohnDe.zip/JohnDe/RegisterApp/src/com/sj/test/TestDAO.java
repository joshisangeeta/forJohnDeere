/**
 * 
 */
package com.sj.test;

import java.sql.SQLException;

import com.sj.dao.DBConnector;
import com.sj.dao.UserDAO;
import com.sj.model.User;

/**
 * @author sangeeta
 *
 */
public class TestDAO {

	public static void main(String[] args) throws SQLException {
		

	            User u = new User (1,"fname","lname","email","password");
	
	           UserDAO.insertUser(u);
	           System.out.println("inserted");
	
	}
	
	
	
}
