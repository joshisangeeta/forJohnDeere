/**
 * 
 */
package com.sj.test;

import java.sql.Connection;
import java.sql.SQLException;

import com.sj.dao.DBConnector;

/**
 * @author sangeeta
 *
 */
public class TestConnection {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

	    Connection con=DBConnector.getInstance().getConncetion();
	
	    System.out.println(con);
	    
	    con.close();
	  
	}

}
