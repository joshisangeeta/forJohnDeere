/**
 * 
 */
package com.sj.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author sangeeta
 *
 */
public class DBConnector {
   static DBConnector dbc;

      private DBConnector(){
    	  try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      }
   
      public static DBConnector getInstance(){
    	  
             if(dbc==null){
            	 return new DBConnector();
             }
             else
            	 return dbc;
     }
     
      public Connection getConncetion(){
    	  
           try {
				return DriverManager.getConnection("jdbc:mysql://localhost:3306/jd","root","root");
			 
               } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 }
           
                 return null;
      }
      
      
      
      
      
      
      
      
      
      
      
      




}
