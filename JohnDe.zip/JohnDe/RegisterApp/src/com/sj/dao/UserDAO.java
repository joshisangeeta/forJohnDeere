/**
 * 
 */
package com.sj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.sj.model.User;

/**
 * @author sangeeta
 *
 */
public class UserDAO {


	
	

        public static User insertUser(User user){
        	
           Connection con=	DBConnector.getInstance().getConncetion();
           Statement statement;
          int id= user.getUid();
         String fn=  user.getFname();
         String ln=  user.getLname();
         String em=  user.getEmail();
         String pass=   user.getPassword();
          
		try {
			  statement = con.createStatement();
		     int i =statement.executeUpdate("insert into user values("+id+","+fn+","+ln+","+em+","+pass+")");
			   
		     } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		    }
           
		       return user; 
        
            }


        public static User getUserById(int id){
        	
        	Connection con=	DBConnector.getInstance().getConncetion();
            try {
				  PreparedStatement pst= con.prepareStatement("select * from user where uid =?");
			      pst.setInt(1, id);
				  ResultSet rs = pst.executeQuery();
                  rs.next();
                  int uid =   rs.getInt(1);
                  String fn=  rs.getString(2);
                  String ln=  rs.getString(3);
                  String em=  rs.getString(4);
                  String pass= rs.getString(5);
                   
                  return new User(uid,fn,ln,em,pass);        
                  
        
              } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			    }
            
              return null;
        	
        	    
        	
        	
        	
        	
        }



}
