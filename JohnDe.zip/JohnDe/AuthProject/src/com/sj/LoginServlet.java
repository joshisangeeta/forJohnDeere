package com.sj;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	        String uname = request.getParameter("uname");
	        String password = request.getParameter("password");
	        PrintWriter out = response.getWriter();
	        
	    if(uname.equals("admin")&& password.equals("admin")) {
	    	   
	    	   out.println("<h1>Welcome"+uname+"</h1>");
	    	   
	       }
	       else
	       {
	    	   
	    	   RequestDispatcher rd = request.getRequestDispatcher("/failure.html");
	    	   
	    	       rd.forward(request, response);
	    	       	   
	    	   
	    	  // out.println("Not a valid user");
	       }
	    	   
	        
	        
	        
	        
	        
	        
	        
	        
	     
	
	}

}
