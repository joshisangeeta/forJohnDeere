/**
 * 
 */
package com.sj.model;

/**
 * @author sangeeta
 *
 */
public class Login {
	
	String uname;
	String password;	
	
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Login(String uname, String password) {
		super();
		this.uname = uname;
		this.password = password;
	}
	
	public boolean isValid(){
		
		if(uname.equals("admin")&& password.equals("admin"))
			
			return true;
		else 
			
			return false;	
		
	}
	
	
	
	
	
	
	
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	
	
	
	

}
