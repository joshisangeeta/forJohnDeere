package RegexDemo.src;

import java.io.File;
import java.util.Scanner;

public class ScannerRegex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	Scanner sc = new Scanner(System.in);
	 //    int i = sc.nextInt();
	 //    System.out.println("i"+i);
	 //   String s1= sc.next();
	 //   System.out.println(s1);
	     
	    /* Scanner sc1 = new Scanner(new File("myNumbers"));
	      while (sc.hasNextLong()) {
	          long aLong = sc.nextLong();
	      }*/
	      String input = "1 fish 2 fish red fish blue fish";
	      Scanner s = new Scanner(input).useDelimiter("\\s*fish\\s*");
	      System.out.println(s.nextInt());
	      System.out.println(s.nextInt());
	      System.out.println(s.next());
	      System.out.println(s.next());
	      s.close(); 
	 

	}

}
