package RegexDemo.src;

import java.util.*;
		import java.util.regex.Pattern;
public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		      String s = "Hello World! 3 + 3.0 = 6 ";

		      // create a new scanner with the specified String Object
		      Scanner scanner = new Scanner(s);

		      // check if next token matches the pattern and print it
		      System.out.println("" + scanner.next(Pattern.compile("..llo")));

		      // check if next token matches the pattern and print it
		      System.out.println("" + scanner.next(Pattern.compile("..rld!")));

		      // close the scanner
		      scanner.close();
		   }
		
	}


